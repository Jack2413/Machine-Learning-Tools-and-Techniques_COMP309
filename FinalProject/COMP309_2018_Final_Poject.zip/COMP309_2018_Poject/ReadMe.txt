@Auther Zhancheng(Jack) Gan
@Student ID 300378961

The code saved in two format, both of them can work.
Currently the text folder and train folder is empty, if you want train or test the model please put the image in the folder use the same format as this project provide. 

Train_data/Test_data
| - strawberry
|	|	- image1.jpg
|	|	- image2.jpg
| - cherry
|	|	- image1.jpg
|	|	- image2.jpg
| - tomato
|	|	- image1.jpg
|	|	- image2.jpg

PS: It takes about 20 min to test my model in my local GPU. Please be patient. If you want to test faster, you can try run on the google colab. To do this you just have to upload the this folder to your google drive and uncomment the online code. Then you all good to go.
